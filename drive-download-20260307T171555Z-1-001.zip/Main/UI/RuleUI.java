package Main.UI;

import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JPanel;

public class RuleUI extends JPanel implements ActionListener {
    
    private JButton cards = new JButton();
    private JButton text = new JButton();
    private JButton frame = new JButton();
    private int count;
    private String [] wold = {"bank", "pon", "mint", "pern", "gam"};
    private ImageIcon [] card_BK = {getScaledIcon("Main\\source_pic\\Recall_card.png"), 
    getScaledIcon("Main\\source_pic\\Sniper_card.png"),
    getScaledIcon("Main\\source_pic\\Unicorn_card.png"),
    getScaledIcon("Main\\source_pic\\Moveplus_card.png"),
    getScaledIcon("Main\\source_pic\\Shield_card.png"),
    };

    public RuleUI(){
        setLayout(null);
        JButton close = new JButton();
        close.addActionListener(this);
        close.setActionCommand("close");
        close.setText("X");
        close.setBackground(Color.RED);
        close.setBounds(968,0,40,40);
        add(close);
        setVisible(false);

        JButton Next = new JButton();
        Next.addActionListener(this);
        Next.setActionCommand("nextp");
        Next.setText(">");
        Next.setBackground(Color.blue);
        Next.setBounds(972, 267, 36, 36);
        add(Next);

        
        JButton Back = new JButton();
        Back.addActionListener(this);
        Back.setActionCommand("backp");
        Back.setText("<");
        Back.setBackground(Color.blue);
        Back.setBounds(0, 267, 36, 36);
        add(Back);

        
        cards.setIcon(card_BK[count]);
        cards.setBackground(null);
        cards.setOpaque(false);
        cards.setBounds(140, 93, 128*2, 192*2);
        cards.setEnabled(false);
        cards.setContentAreaFilled(false);
        cards.setBorderPainted(false);
        add(cards);

        // text.setBackground(null);
        // text.setOpaque(false);
        // text.setBounds(250, 93, 244*2, 176*2);
        // text.setEnabled(false);
        // text.setContentAreaFilled(false);
        // text.setBorderPainted(false);
        // add(text);

        text.setBackground(null);
        text.setOpaque(false);
        // text.setActionCommand("start");
        text.setBounds(280 * 2, 110 * 2, 112 * 2, 48 * 2);
        text.addActionListener(this);
        text.setText(wold[count]);
        text.setFont(new Font("Jacquard 24", Font.PLAIN, 16 * 2));
        add(text);

        frame.setBackground(null);
        frame.setOpaque(false);
        frame.setBounds(430, 93, 244*2, 176*2);
        frame.setEnabled(false);
        frame.setContentAreaFilled(false);
        frame.setBorderPainted(false);
        frame.setIcon(getScaledIcon("Main\\source_pic\\TextFrame.png"));
        add(frame);


        

        


    }
    private ImageIcon getScaledIcon(String path) {
        ImageIcon originalIcon = new ImageIcon(path);

        Image scaledImage = originalIcon.getImage().getScaledInstance(
                originalIcon.getIconWidth() * 2,
                originalIcon.getIconHeight() * 2,
                Image.SCALE_REPLICATE
        );
        return new ImageIcon(scaledImage);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String order = e.getActionCommand();
        if (order.equals("close")){
            setVisible(false);
        }else if(order.equals("nextp")){
            if (count < 5 ){
            count++;
            cards.setIcon(card_BK[count]);
            text.setText(wold[count]);
            }
        }else if(order.equals("backp")){
            if (count != 0){
                count--;
                cards.setIcon(card_BK[count]);
                text.setText(wold[count]);
            }
        }
    }
}


