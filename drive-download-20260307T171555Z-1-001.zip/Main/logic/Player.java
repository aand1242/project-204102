package Main.logic;

public class Player {
    boolean isWhite;
    int score = 50;
    public void resetScore(){
        score = 0;
    }
    public void addScore(int s) {
        score += s;
    }
    public int getScore(){
        return score;
    }
}
